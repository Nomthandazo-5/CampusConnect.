const Message = require("../models/Message");

exports.sendMessage = async (req, res) => {
  const { to, text } = req.body;
  if (!to || !text) return res.status(400).json({ error: "All fields required" });
  try {
    const msg = await Message.create({
      sender: req.user.id,
      recipient: to,
      text
    });
    res.status(201).json(msg);
  } catch {
    res.status(500).json({ error: "Server error" });
  }
};

exports.getMessages = async (req, res) => {
  try {
    const msgs = await Message.find({
      $or: [
        { sender: req.user.id },
        { recipient: req.user.id }
      ]
    }).populate("sender recipient", "name email");
    res.json(msgs);
  } catch {
    res.status(500).json({ error: "Server error" });
  }
};